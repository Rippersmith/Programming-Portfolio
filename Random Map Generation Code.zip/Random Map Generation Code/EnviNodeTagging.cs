﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnviNodeTagging : MonoBehaviour
{
    public List<GameObject> mapNodes;
    protected Vector2 quadrantXAndY; //TODO: change these to 2 actual floats!!
    protected Vector2 center, north, southEast, southWest;

    //add the nodes to use and figure out the center, north, SE, and SW of the quadrant
    public void GetQuadrant(int quadNum, List<GameObject> nodes, Vector2 xAndY)
    {
        mapNodes.AddRange(nodes);
        quadrantXAndY = xAndY;
        center = new Vector2((quadrantXAndY.x / 2), (quadrantXAndY.y / 2));
        north = new Vector2(center.x, center.y + Mathf.Abs(center.y));
        southEast = new Vector2(center.x + Mathf.Abs(center.x), center.y - Mathf.Abs(center.y));
        southWest = new Vector2(center.x - Mathf.Abs(center.x), center.y - Mathf.Abs(center.y));
        StartCoroutine(Pause());
    }

    IEnumerator Pause() //for some reason, the code delays, and if there is an envi. connection, it won't include that in its ConnectedNodes.Count.
                        //This is to ensure that the code has time to catch up.
    {
        yield return new WaitForEndOfFrame();
        StartTagging();
    }

    //the StartTagging function will be overriden by the Envi-Tagging scripts and run the functions appropriate for that script
    public virtual void StartTagging() { print("NOT IMPLEMENTED YET"); }

    //assigns Hubs to quadrants. Hubs are assigned to the center-most node
    protected void HubTag(string tagToReplace, string newTag, Sprite replacementSprite, string newEnum)
    {
        List<GameObject> SuitableNodes = new List<GameObject>();
        GameObject hub = null;
        //first, make a list of all of the nodes that do not have envi. connections attached
        foreach (GameObject node in mapNodes)
        {
            if (node.GetComponent<MapNodeScript>().ConnectedNodes[node.GetComponent<MapNodeScript>().ConnectedNodes.Count - 1].tag == tagToReplace)
                SuitableNodes.Add(node);
        }
        //if there are no appropriate nodes for the Hub, just spawn it on the node closest to the center of the quadrant, regardless of envi. Attachments
        if (SuitableNodes.Count == 0)
        {
            Debug.Log("Error: Not enough available nodes for " + newEnum + " node inside quadrant.");
            foreach (GameObject node in mapNodes)
            {
                if (node.tag == tagToReplace)
                {
                    if (hub == null)
                        hub = node;
                    else if (hub != null && Vector2.Distance(node.transform.position, center) < Vector2.Distance(hub.transform.position, center))
                    {
                        hub = node;
                    }
                }
            }
        }
        //otherwise, make the hub the node closest to the center of the quadrant & has no envi. Connections
        else
        {
            foreach (GameObject node in SuitableNodes)
            {
                if (node.tag == tagToReplace)
                {
                    if (hub == null)
                        hub = node;
                    else if (hub != null && Vector2.Distance(node.transform.position, center) < Vector2.Distance(hub.transform.position, center))
                    {
                        hub = node;
                    }
                }
            }
        }
        //assign tag, sprite, and eNum to Hub
        hub.tag = newTag;
        hub.GetComponent<SpriteRenderer>().sprite = replacementSprite;
        hub.GetComponent<MapNodeScript>().environmentType = (MapNodeScript.NodeType)System.Enum.Parse(typeof(MapNodeScript.NodeType), newEnum);
    }

    //assigns nodes that require random placement
    protected void RandomPlacementTag(string tagToReplace, string newTag, Sprite replacementSprite, string newEnum)
    {
        bool validNode = false;
        int random;
        //only search for the random node if there are available nodes (nodes not already claimed). Otherwise, ignore it and return an error message
        if (GameObject.FindGameObjectsWithTag(tagToReplace).Length > 0)
        {
            //pick a random node. if the random node is available (== tagToReplace), assign tag, sprite, and eNum, otherwise start over
            do
            {
                random = Random.Range(0, mapNodes.Count);
                if (mapNodes[random].tag == tagToReplace)
                {
                    mapNodes[random].tag = newTag;
                    mapNodes[random].GetComponent<SpriteRenderer>().sprite = replacementSprite;
                    mapNodes[random].GetComponent<MapNodeScript>().environmentType = (MapNodeScript.NodeType)System.Enum.Parse(typeof(MapNodeScript.NodeType), newEnum);
                    validNode = true;
                }
            } while (validNode == false);
        }
        else Debug.Log("Error: Not enough available nodes for " + newEnum + " node.");
    }

    //assigns nodes that require to be placed in a specific direction (N, SE, or SW)
    protected void DirectionTag(string tagToReplace, string newTag, Vector2 direction, Sprite replacementSprite, string newEnum)
    {
        GameObject directionNode = mapNodes[0];

        //only search for the directional node if there are available nodes (nodes not already claimed). Otherwise, ignore it and return an error message
        if (GameObject.FindGameObjectsWithTag(tagToReplace).Length > 0)
        {
            //if a node is available and farther in the desinated direction, make it the next best node to use
            foreach (GameObject node in mapNodes)
            {
                if (node.tag == tagToReplace && Vector2.Distance(node.transform.position, direction) < Vector2.Distance(directionNode.transform.position, direction))
                    directionNode = node;
            }
            directionNode.tag = newTag;
            directionNode.GetComponent<SpriteRenderer>().sprite = replacementSprite;
            directionNode.GetComponent<MapNodeScript>().environmentType = (MapNodeScript.NodeType)System.Enum.Parse(typeof(MapNodeScript.NodeType), newEnum);
        }
        else Debug.Log("Error: Not enough available nodes for " + newEnum + " node.");
    }
}