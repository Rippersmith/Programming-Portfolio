﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragonsLairTagging : EnviNodeTagging
{
    public Sprite hubSprite;

    public int smallDragonite = 10;
    public int mediumDragonite = 15;
    public int largeDragonite = 5;

    public override void StartTagging()
    {
        print("DRAGON'S LAIR OVERRIDE");
        DragonsLairHubTag("DragonsLairNode", "DragonsLairHub", hubSprite, "DragonsLairHub");
        AssignDragonite();
    }

    //since Dragon's Lair hub is different from the other hubs, I gave it its own special function
    void DragonsLairHubTag(string tagToReplace, string newTag, Sprite replacementSprite, string newEnum)
    {
        List<GameObject> SuitableNodes = new List<GameObject>();
        GameObject hub = null;
        Vector2 origin = Vector2.zero;
        foreach (GameObject node in mapNodes)
        {
            if (node.GetComponent<MapNodeScript>().ConnectedNodes[node.GetComponent<MapNodeScript>().ConnectedNodes.Count - 1].tag == tagToReplace)
                SuitableNodes.Add(node);
        }

        if (SuitableNodes.Count == 0)
        {
            Debug.Log("Error: Not enough available nodes for " + newEnum + " node inside quadrant.");
            foreach (GameObject node in mapNodes)
            {
                if (node.tag == tagToReplace)
                {
                    if (hub == null)
                        hub = node;
                    else if (hub != null && Vector2.Distance(node.transform.position, origin) > Vector2.Distance(hub.transform.position, origin))
                    {
                        hub = node;
                    }
                }
            }
        }
        else
        {
            foreach (GameObject node in SuitableNodes)
            {
                if (node.tag == tagToReplace)
                {
                    if (hub == null)
                        hub = node;
                    else if (hub != null && Vector2.Distance(node.transform.position, origin) > Vector2.Distance(hub.transform.position, origin))
                    {
                        hub = node;
                    }
                }
            }
        }
        hub.tag = newTag;
        hub.GetComponent<SpriteRenderer>().sprite = replacementSprite;
        hub.GetComponent<MapNodeScript>().environmentType = (MapNodeScript.NodeType)System.Enum.Parse(typeof(MapNodeScript.NodeType), newEnum);
    }

    void AssignDragonite()
    {
        while (largeDragonite > 0)
        {
            foreach (GameObject node in mapNodes)
            {
                if (node.tag != "DragonsLairHub")
                {
                    if (smallDragonite > 0)
                    {
                        node.GetComponent<DragoniteValues>().smallValue++;
                        smallDragonite--;
                    }
                    else if (smallDragonite == 0 && mediumDragonite > 0)
                    {
                        node.GetComponent<DragoniteValues>().mediumValue++;
                        mediumDragonite--;
                    }
                    else if (smallDragonite == 0 && mediumDragonite == 0 && largeDragonite > 0)
                    {
                        node.GetComponent<DragoniteValues>().largeValue++;
                        largeDragonite--;
                    }
                }
            }
        }
    }
}