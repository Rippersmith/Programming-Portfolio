﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement; // for when we eventually need to transfer between the nodes and the actual map

public class MapNodeScript : MonoBehaviour
{
    [System.Serializable]
    public struct NodeAndDistance
    {
        public GameObject neighborNode;
        public float neighborNodeDistance;
        public NodeAndDistance(GameObject node, float distance)
        {
            neighborNode = node;
            neighborNodeDistance = distance;
        }
    }
    public enum NodeType
    {
        Nothing,
        GroveHub, GroveFlameLake, GroveFrostLake, GroveLightningLake, GroveMistLake, GroveSpidersLair, GroveDesert, GroveMeadow,
        JungleHub, JungleKnightsLanding, JungleCatacombs, JungleDesert, JungleMeadow,
        SeabedHub, SeabedDeepSeawater, SeabedSeaOpening, SeabedDeepMeadow,
        DragonsLairHub
    }

    public NodeType environmentType = NodeType.Nothing;
    public bool connected = false;
    public List<GameObject> ConnectedNodes;
    public List<GameObject> KeepConnections;
    public List<NodeAndDistance> ConnectingNodeInfo;
    public GameObject connectorPrefab;

    RaycastHit2D[] rayHit;
    GameObject mapNode;
    NodeAndDistance newInstance;
    float raycastRot = 0f;
    int maxConnections;
    int currentConnections = 0;

    //assign num of Connections to use and shoot rays out in multiple directions
    void Start()
    {
        maxConnections = Random.Range(1, 4);

        rayHit = new RaycastHit2D[24];
        for (int i = 0; i < 24; i++)
        {
            rayHit[i] = Physics2D.Raycast(transform.position, new Vector2(Mathf.Sin(raycastRot), Mathf.Cos(raycastRot)), Mathf.Infinity);
            raycastRot += 15;
        }
    }

    //use this update only when testing with the DrawRays
    /*void Update()
    {
        for (int i = 0; i < 24; i++)
        {
              if (rayHit[i].collider != null && rayHit[i].collider.tag != "EnviBorder" &&
                (ConnectedNodes.Contains(rayHit[i].collider.gameObject) || rayHit[i].collider.GetComponent<MapNodeScript>().ConnectedNodes.Contains(gameObject)))
            {
                Debug.DrawRay(transform.position, rayHit[i].collider.transform.position - transform.position, Color.black);
            }
        }
    }*/

    //find any rays that connect to another node, and add it to the ConnectedNodes list as a potential connection (same with the node it finds),
    //and increase currentConnections by 1
    public void FindConnectionNodes()
    {
        for (int i = 0; i < 24; i++)
        {
            if (rayHit[i].collider != null && rayHit[i].collider.tag != "EnviBorder" &&
               (!rayHit[i].collider.GetComponent<MapNodeScript>().ConnectedNodes.Contains(gameObject) &&
               !ConnectedNodes.Contains(rayHit[i].collider.gameObject)))
            {
                ConnectedNodes.Add(rayHit[i].collider.gameObject);
                rayHit[i].collider.GetComponent<MapNodeScript>().ConnectedNodes.Add(gameObject);
                currentConnections++;
                rayHit[i].collider.GetComponent<MapNodeScript>().currentConnections++;
            }
        }
        UpdateNodeConnections();
    }

    //make a new NodeAndDistance for each object, add it to the ConnectingNodeInfo list, then sort the list of connected nodes by distance
    void UpdateNodeConnections()
    {
        for (int a = 0; a < ConnectedNodes.Count; a++)
        {
            newInstance = new NodeAndDistance(ConnectedNodes[a].gameObject, Vector2.Distance(ConnectedNodes[a].transform.position, transform.position));
            ConnectingNodeInfo.Add(newInstance);
        }

        //sort the connections by longest distance first
        for (int b = ConnectingNodeInfo.Count - 1; b >= 0; b--)
        {
            if (b + 1 < ConnectingNodeInfo.Count)
            {
                if (ConnectingNodeInfo[b].neighborNodeDistance < ConnectingNodeInfo[b + 1].neighborNodeDistance)
                {
                    NodeAndDistance temp = ConnectingNodeInfo[b];
                    ConnectingNodeInfo[b] = ConnectingNodeInfo[b + 1];
                    ConnectingNodeInfo[b + 1] = temp;
                    b += 2;
                }
            }
        }
    }

    //start cutting connections 
    public void PrioritizeConnections()
    {
        //as long as there are more objects in the ConnectingNodeInfo list, keep deleting the 1st (and therefore the longest) node on the ConnectedNodes & ConnectingNodeInfo lists 
        while (ConnectingNodeInfo.Count > maxConnections)
        {
            ConnectedNodes.Remove(ConnectingNodeInfo[0].neighborNode);
            ConnectingNodeInfo.RemoveAt(0);
        }
    }

    //start making the paths between nodes within an environment
    public void CreatePaths()
    {
        for (int a = 0; a < ConnectedNodes.Count; a++)
        {
            RaycastHit2D rayCheck = Physics2D.Raycast(transform.position, (ConnectedNodes[a].transform.position - transform.position), Mathf.Infinity);
            if (rayCheck.collider != null && rayCheck.collider.tag != "ConnectionPath" && rayCheck.collider.tag != "EnviBorder")
            {
                //instantiate connector, attach to node as parent (to help in case of needing to delete entire quadrant),
                //and attach ends of LineRenderer b/w this node & the one it's connecting to...
                GameObject newLine = Instantiate(connectorPrefab, transform.position, Quaternion.identity);
                newLine.transform.parent = gameObject.transform;
                newLine.GetComponent<LineRenderer>().SetPosition(0, transform.position);
                newLine.GetComponent<LineRenderer>().SetPosition(1, ConnectedNodes[a].transform.position);

                //then rotate & stretch out BoxCollider to fit collider
                float angle = Mathf.Atan2(ConnectedNodes[a].transform.position.y - transform.position.y,
                    ConnectedNodes[a].transform.position.x - transform.position.x) * 180f / Mathf.PI;
                newLine.transform.rotation = Quaternion.AngleAxis(angle - 90f, Vector3.forward);
                newLine.GetComponent<BoxCollider2D>().offset = new Vector2(0f, (Vector2.Distance(ConnectedNodes[a].transform.position, transform.position) / 2f));
                newLine.GetComponent<BoxCollider2D>().size = new Vector2(.15f, Vector2.Distance(ConnectedNodes[a].transform.position, transform.position));

                //if this node doesn't have the connected node in its ConnectedNodes, OR the other object doesn't have this object in its ConnectedNodes list,
                //add each other to the others' list
                if (!KeepConnections.Contains(ConnectedNodes[a]))
                    KeepConnections.Add(ConnectedNodes[a]);
                if (!ConnectedNodes[a].GetComponent<MapNodeScript>().KeepConnections.Contains(gameObject))
                    ConnectedNodes[a].GetComponent<MapNodeScript>().KeepConnections.Add(gameObject);
            }
        }
        ConnectedNodes.Clear();
    }
}
