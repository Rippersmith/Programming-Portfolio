﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroveTagging : EnviNodeTagging
{
    public Sprite hubSprite;
    public Sprite flameLakeSprite;
    public Sprite frostLakeSprite;
    public Sprite lightningLakeSprite;
    public Sprite mistLakeSprite;
    public Sprite spiderLairSprite;
    public Sprite desertSprite;
    public Sprite meadowSprite;

    //override StartTagging function & spawn in special order
    //spawn order; Hub, Flame Lake, Frost Lake, Lake of Lightning, Mist Lake, Spider's Lair, 2 Deserts, Meadow
    public override void StartTagging()
    {
        print("GROVE OVERRIDE");
        HubTag("GroveNode", "GroveHub", hubSprite, "GroveHub");
        DirectionTag("GroveNode", "FlameLake", north, flameLakeSprite, "GroveFlameLake");
        DirectionTag("GroveNode", "FrostLake", southEast, frostLakeSprite, "GroveFrostLake");
        DirectionTag("GroveNode", "LightningLake", southWest, lightningLakeSprite, "GroveLightningLake");
        RandomPlacementTag("GroveNode", "MistLake", mistLakeSprite, "GroveMistLake");
        RandomPlacementTag("GroveNode", "SpiderLair", spiderLairSprite, "GroveSpidersLair");
        for (int d = 0; d < 2; d++) { RandomPlacementTag("GroveNode", "GroveDesert", desertSprite, "GroveDesert"); }
        RandomPlacementTag("GroveNode", "GroveMeadow", meadowSprite, "GroveMeadow");
    }
}