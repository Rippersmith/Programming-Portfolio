﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMapNodeGeneration : MonoBehaviour
{
    public List<GameObject> mapNodes;
    public List<GameObject> CurrentNodesConnecting;
    public List<GameObject> NextNodesToConnect;
    public List<GameObject> CrossNodesOurs, CrossNodesTheirs;
    public GameObject mapNodePrefab, mapConnectorPrefab;

    public Vector2 xRange, yRange;

    public string findInAdjacentQuadrant = "";
    public int spawnNodes;
    public int quadrantNum = 0;
    int numMaxCrossConns;

	RootEnvironment rootEnvi;
    AssignToQuadrants assignQuadrants;

    // Use this for initialization
    void Start()
    {
		rootEnvi = GetComponentInParent<RootEnvironment>();
        assignQuadrants = GameObject.Find("AssignQuadrants").GetComponent<AssignToQuadrants>();

        if (rootEnvi == null)
			Debug.Log ("ERROR: No root environment found - this will cause problems");

        if (spawnNodes < 6) spawnNodes = 6;
        else if (spawnNodes > 28) spawnNodes = 28;

        numMaxCrossConns = spawnNodes / 2;
        SpawnNewNodes();//spawn new nodes
        StartCoroutine(SpawnMapNodes());//spawn nodes & connect them in their own quadrants

    }

    void SpawnNewNodes()
    {
        for (int i = 0; i < spawnNodes; i++)
        {
            bool continueOn = false;
            while (continueOn == false)
            {
                Vector2 spawnPoint = new Vector2(Random.Range(xRange.x, xRange.y), Random.Range(yRange.x, yRange.y));
                bool areaCheck = Physics2D.OverlapCircle(spawnPoint, 1.4f);
                if (!areaCheck)
                {
					GameObject newNode = Instantiate (mapNodePrefab, spawnPoint, Quaternion.identity);
					mapNodes.Add(newNode);
					Debug.Log ("Newnode mapnodescript: " + newNode.GetComponent<MapNodeScript> ());
					Debug.Log ("rootEnvi: " + (rootEnvi == null));
					rootEnvi.allNodes.Add(newNode.GetComponent<MapNodeScript>());
                    continueOn = true;
                }
            }
        }
    }

    //this is the code to check to see if all of the nodes are connected in the environment
    //if not, delete the whole quadrant and start again
    void CheckForFullEnvironment()
    {
        int loop;
        bool repeatSearch = true;

        //use mapNodes[0] as a starting point
        CurrentNodesConnecting.Add(mapNodes[0]);

        //as long as there is no confirmed connection and the path continues going on
        while (repeatSearch == true)
        {
            //for every node in the CurrentNodesConnecting list
            for (loop = 0; loop < CurrentNodesConnecting.Count; loop++)
            {
                //add connected nodes to list of nodes to add to CurrentNodesConnecting on this object
                foreach (GameObject nodeToAdd in CurrentNodesConnecting[loop].GetComponent<MapNodeScript>().ConnectedNodes)
                {
                    //if the node is not already in the list of nodes to connect to/about to connect to, add it
                    if (!NextNodesToConnect.Contains(nodeToAdd) && !CurrentNodesConnecting.Contains(nodeToAdd))
                    {
                        NextNodesToConnect.Add(nodeToAdd);
                    }
                }
            }
            CurrentNodesConnecting.AddRange(NextNodesToConnect);
            if (NextNodesToConnect.Count == 0) repeatSearch = false;
            NextNodesToConnect.Clear();
        }
        //If all of the nodes are connected, set one of the values in the quadsAllReady to true
        if (CurrentNodesConnecting.Count == spawnNodes)
        {
            assignQuadrants.quadsAllReady[quadrantNum] = true;
        }
        //else, delete everything and start from scratch
        else
        {
            foreach (GameObject dropNode in mapNodes)
            {
                Destroy(dropNode);
				rootEnvi.allNodes.Remove(dropNode.GetComponent<MapNodeScript>());
            }
            mapNodes.Clear();
            CurrentNodesConnecting.Clear();
            SpawnNewNodes();
            StartCoroutine(SpawnMapNodes());
        }
        //if all values in the quadsAllReady array are true, start the function that will start the environment connections
        if (assignQuadrants.quadsAllReady[0] == true && assignQuadrants.quadsAllReady[1] == true &&
            assignQuadrants.quadsAllReady[2] == true && assignQuadrants.quadsAllReady[3] == true)
        {
            assignQuadrants.StartEnviConnections();
        }
    }

    //responsible for spawning all the nodes in one quadrant
    IEnumerator SpawnMapNodes()
    {
        int loop = 0;

        //give time for the SpawnNewNodes script to catch up
        yield return new WaitForSeconds(0.3f);

        //do FindConnectionNodes separate from others, otherwise we get weirder configurations
        for (loop = 0; loop < mapNodes.Count; loop++)
        {
            mapNodes[loop].GetComponent<MapNodeScript>().FindConnectionNodes();
        }

        for (loop = 0; loop < mapNodes.Count; loop++)
        {
            mapNodes[loop].GetComponent<MapNodeScript>().PrioritizeConnections();
            //empty ConnectedNodes and refill with nodes that the node could actually connect to
            mapNodes[loop].GetComponent<MapNodeScript>().ConnectedNodes.Clear();
            for (int c = 0; c < mapNodes[loop].GetComponent<MapNodeScript>().ConnectingNodeInfo.Count; c++)
            {
                mapNodes[loop].GetComponent<MapNodeScript>().ConnectedNodes.Add(mapNodes[loop].GetComponent<MapNodeScript>().ConnectingNodeInfo[c].neighborNode);
            }
        }

        //let code play catch-up
        yield return new WaitForSeconds(.5f);

        //have the nodes start creating paths
        for (loop = 0; loop < mapNodes.Count; loop++)
        {
            mapNodes[loop].GetComponent<MapNodeScript>().CreatePaths();
        }

        //fill ConnectedNodes with more appropriate connections, then make KeepConnections null b/c we don't need it anymore
        for (loop = 0; loop < mapNodes.Count; loop++)
        {
            mapNodes[loop].GetComponent<MapNodeScript>().ConnectedNodes.AddRange(mapNodes[loop].GetComponent<MapNodeScript>().KeepConnections);
            mapNodes[loop].GetComponent<MapNodeScript>().KeepConnections = null;
        }

        print("Individual Groups: Done");
        CheckForFullEnvironment();
    }

    public void ConnectToOtherEnvis()
    {
        GameObject otherEnvi = GameObject.Find(findInAdjacentQuadrant);

        //way quadrants are set up:
        //      0>  |   1v
        //    -------------     //arrows point in the direction of where the NodeGenerator is searching for connections (CrossNodesTheirs)
        //      3^  |  <2

        //add nodes to CrossNodesOurs & CrossNodesTheirs
        CrossNodesOurs.AddRange(mapNodes);
        CrossNodesTheirs.AddRange(otherEnvi.GetComponent<RandomMapNodeGeneration>().mapNodes);

        //if the number of nodes in CrossNodesOurs is less than all of the nodes in the other quadrant,
        //cut down the number of connections to the number of nodes in otherEnvi (this will definitely be a far safer # of nodes to use)
        if (CrossNodesTheirs.Count < numMaxCrossConns)
            numMaxCrossConns = CrossNodesTheirs.Count;

        //if the generator is searching for connections across the y-axis (quadrant 0 or 2), use this
        if (quadrantNum % 2 == 0)
        {
            SortXAxis(CrossNodesOurs);
            SortXAxis(CrossNodesTheirs);
        }

        //if the generator is searching for connections across the X-axis (quadrant 1 or 3), use this
        else if (quadrantNum % 2 == 1)
        {
            SortYAxis(CrossNodesOurs);
            SortYAxis(CrossNodesTheirs);
        }

        //remove the nodes from CrossNodesOurs & CrossNodesTheirs so that only a few applicable nodes are checked to see oif they can be connected (nodes/2)
        //Must do seperately in case there are different # of nodes in quadrants
        while (CrossNodesOurs.Count > numMaxCrossConns)
        {
            CrossNodesOurs.RemoveAt(CrossNodesOurs.Count - 1);
        }

        while (CrossNodesTheirs.Count > numMaxCrossConns)
        {
            CrossNodesTheirs.RemoveAt(CrossNodesTheirs.Count - 1);
        }

        SortConnections();
    }

    //sort nodes depending on how close they are to the X-axis
    void SortXAxis(List<GameObject> nodeList)
    {
        for (int b = 1; b < nodeList.Count; b++)
        {
            if (b > 0)//since we can decrease b by 2 and there is no mapNodes[-1], we need this as a safeguard for errors
            {
                if (Vector2.Distance(nodeList[b - 1].transform.position, new Vector2(0, nodeList[b - 1].transform.position.y)) >
                    Vector2.Distance(nodeList[b].transform.position, new Vector2(0, nodeList[b].transform.position.y)))
                {
                    b = Sort(nodeList, b);
                }
            }
        }
    }

    //sort nodes depending on how close they are to the Y-Axis
    void SortYAxis(List<GameObject> nodeList)
    {
        for (int b = 1; b < nodeList.Count; b++)
        {
            if (b > 0)//since we can decrease b by 2 and there is no mapNodes[-1], we need this as a safeguard for errors
            {
                if (Vector2.Distance(nodeList[b - 1].transform.position, new Vector2(nodeList[b - 1].transform.position.x, 0)) >
                    Vector2.Distance(nodeList[b].transform.position, new Vector2(nodeList[b].transform.position.x, 0)))
                {
                    b = Sort(nodeList, b);
                }
            }
        }
    }

    //switch the nodes in "nodeNum" and "nodeNum - 1", and subtract & return the loop # by 2 (can compare the new "nodeNum - 1" to "nodeNum - 2")
    int Sort(List<GameObject> nodeList, int nodeNum)
    {
        GameObject temp = nodeList[nodeNum - 1];
        nodeList[nodeNum - 1] = nodeList[nodeNum];
        nodeList[nodeNum] = temp;
        nodeNum -= 2;
        return nodeNum;
    }

    //try and find the best connections between CrossNodesOurs & CrossNodesTheirs by comparing distances
    void SortConnections()
    {
        float shortestDist = Mathf.Infinity;
        int nodeToSwitch = -1, increaseTheirNode = 0;
        for (int ourLoop = 0; ourLoop < CrossNodesOurs.Count; ourLoop++)
        {
            for (int theirLoop = increaseTheirNode; theirLoop < CrossNodesTheirs.Count; theirLoop++)
            {
                if (Vector2.Distance(CrossNodesOurs[ourLoop].transform.position, CrossNodesTheirs[theirLoop].transform.position) < shortestDist)
                {
                    nodeToSwitch = theirLoop;
                    shortestDist = Vector2.Distance(CrossNodesOurs[ourLoop].transform.position, CrossNodesTheirs[theirLoop].transform.position);
                }
            }

            GameObject temp = CrossNodesTheirs[ourLoop];
            CrossNodesTheirs[ourLoop] = CrossNodesTheirs[nodeToSwitch];
            CrossNodesTheirs[nodeToSwitch] = temp;

            shortestDist = Mathf.Infinity;
            increaseTheirNode++;
        }
        CutEnviConnections(CrossNodesOurs, CrossNodesTheirs);
    }

    //cut node connections depending on obstructions
    void CutEnviConnections(List<GameObject> ours, List<GameObject> theirs)
    {
        //disable the borders, otherwise they will get in the way (won't be able to detect the nodes behind them
        GameObject[] borders = GameObject.FindGameObjectsWithTag("EnviBorder");
        foreach (GameObject border in borders)
            border.GetComponent<BoxCollider2D>().enabled = false;

        for (int a = 0; a < numMaxCrossConns; a++)
        {
            //Raycast  between the current node and the node it wants to connect with
            RaycastHit2D rayCheck = Physics2D.Raycast(ours[a].transform.position + (theirs[a].transform.position - ours[a].transform.position) * .01f,
                (theirs[a].transform.position - ours[a].transform.position), Mathf.Infinity);
            //if rayCheck hits something, and it's not another envi. connection, and the object it finds is the object it wants, AND the distance is short enough, OR
            //it's the first connection on the list (safeguard to guarantee that there is at least 1 connection b/w environments
            if (rayCheck.collider != null && (rayCheck.collider.tag != "EnvironmentConnectionPath" &&
                rayCheck.collider.gameObject == theirs[a] &&
                Vector2.Distance(ours[a].transform.position, theirs[a].transform.position) < 11f) || a == 0)
            {
                //instantiate new connector & connect its LineRenderer b/w the 2 nodes...
                GameObject connector = Instantiate(mapConnectorPrefab, ours[a].transform.position, Quaternion.identity);
                connector.GetComponent<LineRenderer>().SetPosition(0, ours[a].transform.position);
                connector.GetComponent<LineRenderer>().SetPosition(1, theirs[a].transform.position);

                //then take the BoxCollider & rotate it & stretch it out so that it covers the entire connector object...
                float angle = Mathf.Atan2(theirs[a].transform.position.y - ours[a].transform.position.y,
                        theirs[a].transform.position.x - ours[a].transform.position.x) * 180f / Mathf.PI;
                connector.transform.rotation = Quaternion.AngleAxis(angle - 90f, Vector3.forward);
                connector.GetComponent<BoxCollider2D>().offset = new Vector2(0f, (Vector2.Distance(theirs[a].transform.position, ours[a].transform.position) / 2f));
                connector.GetComponent<BoxCollider2D>().size = new Vector2(.15f, Vector2.Distance(theirs[a].transform.position, ours[a].transform.position));

                //then add each node to the other's ConnectedNodes
                ours[a].GetComponent<MapNodeScript>().ConnectedNodes.Add(theirs[a]);
                theirs[a].GetComponent<MapNodeScript>().ConnectedNodes.Add(ours[a]);
            }
        }
        GetComponent<EnviNodeTagging>().GetQuadrant(quadrantNum, mapNodes, new Vector2(xRange.x, yRange.x));
    }
}
