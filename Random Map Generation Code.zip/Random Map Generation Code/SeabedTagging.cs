﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SeabedTagging : EnviNodeTagging
{
    public Sprite hubSprite;
    public Sprite deepSeawaterSprite;
    public Sprite seasOpeningSprite;
    public Sprite seasDeepMeadowSprite;

    //override StartTagging function & spawn in special order
    //spawn order; Hub, 3 Deep Seawaters, Deep Meadow, 2 Seabed Openings
    public override void StartTagging()
    {
        print("SEABED OVERRIDE");
        HubTag("SeabedNode", "SeabedHub", hubSprite, "SeabedHub");
        DirectionTag("SeabedNode", "DeepSeawater", north, deepSeawaterSprite, "SeabedDeepSeawater");
        DirectionTag("SeabedNode", "DeepSeawater", southEast, deepSeawaterSprite, "SeabedDeepSeawater");
        DirectionTag("SeabedNode", "DeepSeawater", southWest, deepSeawaterSprite, "SeabedDeepSeawater");
        RandomPlacementTag("SeabedNode", "SeaDeepMeadow", seasDeepMeadowSprite, "SeabedDeepMeadow");
        for (int d = 0; d < 2; d++) { RandomPlacementTag("SeabedNode", "SeaOpening", seasOpeningSprite, "SeabedSeaOpening"); }
    }
}