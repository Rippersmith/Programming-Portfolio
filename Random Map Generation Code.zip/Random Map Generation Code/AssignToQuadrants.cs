﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AssignToQuadrants : MonoBehaviour
{
    Vector2    topHalf = new Vector2(11f, 1f), // Y
               bottomHalf = new Vector2(-11f, -1f), // -Y
               rightSide = new Vector2(15f, 1f), // X
               leftSide = new Vector2(-15f, -1f); // -X

    int[] quadArray = { 0, 1, 2, 3 };
    public bool[] quadsAllReady = { false, false, false, false };
    GameObject[] environments = { null, null, null, null };

    // Use this for initialization
    void Start()
    {
        //set this in the Physics2D settings to make the nodes work correctly, otherwise they'll just stop at themselves and won't connect to anything.
        //TODO: change the settings when we go into the maps
        Physics2D.queriesStartInColliders = false;
        //at the start, assign each EnviGeneration object to a spot in the environments array
        environments[0] = GameObject.Find("GroveEnviGeneration"); //Grove
        environments[1] = GameObject.Find("JungleEnviGeneration"); //Jungle
        environments[2] = GameObject.Find("SeabedEnviGeneration"); //Seabed
        environments[3] = GameObject.Find("DragonsLairEnviGeneration"); //DragonsLair
        AssignQuad();
    }

    //assign each environment a random # between 0 & 3, representing a quadrant
    void AssignQuad()
    {
        //Fisher-Yates shuffle to mix up quadrant assignment
        for (int i = 3; i >= 0; i--)
        {
            int j = Random.Range(0, 4);
            int swap = quadArray[i];
            quadArray[i] = quadArray[j];
            quadArray[j] = swap;
        }

        //assign an environment to a quadrant...
        AssignNewQuadrants(0, leftSide, topHalf);
        AssignNewQuadrants(1, rightSide, topHalf);
        AssignNewQuadrants(2, rightSide, bottomHalf);
        AssignNewQuadrants(3, leftSide, bottomHalf);

        //then find the adjacent quadrant to it (doing it at same time as AssignNewQuadrant could have no quadrant to be adjacent to)
        FindInAdjacentQuadrant(0, 1);
        FindInAdjacentQuadrant(1, 2);
        FindInAdjacentQuadrant(2, 3);
        FindInAdjacentQuadrant(3, 0);
    }

    //assign the quadrantNum and x & y ranges to the RandomMapNodeGenerations
    void AssignNewQuadrants(int quadrant, Vector2 xRange, Vector2 yRange)
    {
        environments[quadArray[quadrant]].GetComponent<RandomMapNodeGeneration>().quadrantNum = quadrant;
        environments[quadArray[quadrant]].GetComponent<RandomMapNodeGeneration>().xRange = xRange;
        environments[quadArray[quadrant]].GetComponent<RandomMapNodeGeneration>().yRange = yRange;
    }

    //figure out what the adjacent quadrant is by using the adjacent quadrant's name
    void FindInAdjacentQuadrant(int assignTo, int assignFrom)
    {
        environments[quadArray[assignTo]].GetComponent<RandomMapNodeGeneration>().findInAdjacentQuadrant = environments[quadArray[assignFrom]].name;
    }

    //start connecting the environments to each other 
    public void StartEnviConnections()
    {
        for (int i = 0; i <= 3; i++)
        {
            environments[i].GetComponent<RandomMapNodeGeneration>().ConnectToOtherEnvis();
        }
    }
}
