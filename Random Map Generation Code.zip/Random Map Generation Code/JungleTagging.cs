﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class JungleTagging : EnviNodeTagging
{
    public Sprite hubSprite;
    public Sprite knightsLandingSprite;
    public Sprite catacombsSprite;
    public Sprite desertSprite;
    public Sprite meadowSprite;

    //override StartTagging function & spawn in special order
    //spawn order; Hub, Knight's Landing, Catacombs, 2 Deserts, Meadow, 2 Deserts, Meadow
    public override void StartTagging()
    {
        print("JUNGLE OVERRIDE");
        HubTag("JungleNode", "JungleHub", hubSprite, "JungleHub");
        SpecialTag("KnightLanding", "Catacombs", knightsLandingSprite, "JungleKnightsLanding");
        SpecialTag("Catacombs", "KnightLanding", catacombsSprite, "JungleCatacombs");

        //in order to add variety in the case of 6 nodes, I split up the Desert & Meadow spawns
        //so that there will be at least 1 meadow node available
        for (int c = 0; c < 2; c++)
        {
            for (int d = 0; d < 2; d++) { RandomPlacementTag("JungleNode", "JungleDesert", desertSprite, "JungleDesert"); }
            RandomPlacementTag("JungleNode", "JungleMeadow", meadowSprite, "JungleMeadow");
        }
        StartCoroutine(Restart()); //delete when needed
    }

    //Since this function is only used in the Jungle, I left this function here
    //Assigns a tag to a node that isn't attached to the hub or "tagToAvoid" (overwritten if no such node exists to random placement)
    void SpecialTag(string newTag, string tagToAvoid, Sprite replacementSprite, string newEnum)
    {
        bool validNode = false;
        List<GameObject> SuitableNodes = new List<GameObject>();
        int random;
        foreach (GameObject node in mapNodes)
        {
            if (node.tag == "JungleNode" &&
                !node.GetComponent<MapNodeScript>().ConnectedNodes.Contains(GameObject.FindGameObjectWithTag("JungleHub")) &&
                !node.GetComponent<MapNodeScript>().ConnectedNodes.Contains(GameObject.FindGameObjectWithTag(tagToAvoid)))
                SuitableNodes.Add(node);
        }
        //print(newTag + " ERROR TEST: " + SuitableNodes.Count);
        if ((SuitableNodes.Count) < 1)
        {
            RandomPlacementTag("JungleNode", newTag, replacementSprite, newEnum);
        }
        else
        {
            do
            {
                random = Random.Range(0, SuitableNodes.Count);
                //if (SuitableNodes[random].tag == "JungleNode")
				if (SuitableNodes[random].tag == "JungleNode")
                {
                    SuitableNodes[random].tag = newTag;
                    SuitableNodes[random].GetComponent<SpriteRenderer>().sprite = replacementSprite;
                    SuitableNodes[random].GetComponent<MapNodeScript>().environmentType = (MapNodeScript.NodeType)System.Enum.Parse(typeof(MapNodeScript.NodeType), newEnum);
                    validNode = true;
                }
            } while (validNode == false);
        }
    }

    //THIS IS FOR TESTING ONLY, DELETE LATER
    IEnumerator Restart()
    {
        yield return new WaitForSeconds(1.2f);
        SceneManager.LoadScene(0);
    }
}
